public class Basic13Test {
    public static void main(String[] args){
    Basic13 printNums =  new Basic13();
    printNums.print1to255();

    Basic13 Odds = new Basic13();
    Odds.printOdd();

    Basic13 sum = new Basic13();
    sum.sumNums();

    int[] myArr = {10,20,30,-40};
    Basic13 loopArr = new Basic13();
    loopArr.iterArr(myArr);

    Basic13 max = new Basic13();
    System.out.println(max.findMax(myArr));

    Basic13 average = new Basic13();
    System.out.println(average.findAvg(myArr));

    Basic13 arrayOfOdd = new Basic13();
    System.out.println(arrayOfOdd.oddArray());

    Basic13 squareValues = new Basic13();
    System.out.println(squareValues.findSquares(myArr));

    Basic13 negatives = new Basic13();
    System.out.println(negatives.noNegs(myArr));

    Basic13 minMaxAverage = new Basic13();
    System.out.println(minMaxAverage.minMaxAvg(myArr));

    Basic13 shiftArray = new Basic13();
    System.out.println(shiftArray.shiftValues(myArr));

}
}
