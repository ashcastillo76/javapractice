/**
 * 
 */
/**
 * @author ashca
 *
 */
package com.ashley.authentication.models;