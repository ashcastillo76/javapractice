package com.ashley;

public interface Ringable {
	String ring();
	String unlock();
	void displayInfo();

}
