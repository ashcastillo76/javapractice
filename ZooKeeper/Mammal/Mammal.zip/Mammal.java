public class Mammal{
    int energyLevel;

    public int displayEnergy(){
        System.out.println(energyLevel);
        return energyLevel;
    }

}