
public class FizzBuzzTest {
        public static void main(String[] args){
            FizzBuzz fb = new FizzBuzz();
            System.out.println(fb.fizzBuzz(5));
    }
}
